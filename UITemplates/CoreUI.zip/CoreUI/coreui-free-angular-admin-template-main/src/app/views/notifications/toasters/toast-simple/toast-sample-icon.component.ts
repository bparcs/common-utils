import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'toast-sample-icon',
  templateUrl: './toast-sample-icon.component.svg',
})
export class ToastSampleIconComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
